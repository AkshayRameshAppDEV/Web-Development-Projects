var express = require("express");
var app = express();
app.get("/",function(req,res)
{
    res.send("Hi there!");
});

app.get("/bye",function(req,res)
{
    res.send("GOOD BYE!");
});

app.get("/cat",function(req,res)
{
    console.log("SOMEONE REQUESTED")
    res.send("MEOWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
});

app.get("/r/:subredditName",function(req, res) 
{
    var sub = Number(req.params.subredditName);
    
    for(var i=0;i<sub;i++)
    {
              res.send("WELCOME TO SUBREDDIT");
    }
    

});

app.get("/r/:subredditName/comments/:id/:title",function(req, res) 
{
    res.send("WELCOME to comments page");
    
});


app.get("*",function(req, res) 
{
    res.send("YOU ARE A STAR");
});

app.listen(process.env.PORT,process.env.IP,function()
{
    console.log("Server has started!!!!")
});
