var express = require("express");
var app = express();

app.get("/",function(req,res)
{
    res.send("Hi there, welcome to my assignment!");
    
});

app.get("/speak/:greet/:number",function(req,res){
    var msg = req.params.greet;
    var num = Number(req.params.number);
    for(var i=1;i<=num;i++)
    {
         res.write(msg+" ");
    }
   
    res.end();
   
    
})

app.listen(process.env.PORT,process.env.IP,function(){
    console.log("SERVER")
    
});
