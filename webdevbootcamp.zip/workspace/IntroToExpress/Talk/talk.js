var express = require("express");
var app = express();

app.get("/",function(req,res)
{
    res.send("Hi there, welcome to my assignment!");
    
});

app.get("/speak/:animal",function(req,res)
{
   var animalDomestic = req.params.animal;
   
   if(animalDomestic === "pig")
   {
       res.send("The pig says 'oink'");
   }
   else if(animalDomestic === "cow")
   {
       res.send("The cow says 'Moo'");
   }
   else if(animalDomestic === "dog")
   {
       res.send("The dog says 'Woof Woof'");
   }
    
});

app.get("/repeat/:greet/:number",function(req,res){
    var msg = req.params.greet;
    var num = Number(req.params.number);
    for(var i=1;i<=num;i++)
    {
         res.write(msg+"\n");
    }
   
    res.end();
   
    
})

app.get("*",function(req,res)
{
    res.send("!!!!SORRY PAGE NOT FOUND!!!!!");
    
});

app.listen(process.env.PORT,process.env.IP,function(){
    console.log("SERVER CONNECTION ESTABLISHED!!!")
    
});

