function echo(strng,number)
{
    for(var i=1;i<=number;i++)
    {
        console.log(strng);
    }
    
}

echo("Echo!!!",10);
console.log("-------------------------");
echo("Tater Tots",3);