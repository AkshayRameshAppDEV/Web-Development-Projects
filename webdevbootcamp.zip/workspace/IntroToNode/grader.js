var scores = [90,98,89,100,100,86,94];
var scores2 = [40,65,77,82,80,54,73,63,95,49];


function average(scoresArray)
{
    var avgSum = 0;
    var avg=0;
    for(var i=0;i<scoresArray.length;i++)
    {
        avgSum += scoresArray[i];
    
    }
    avg = avgSum/scoresArray.length;
    return Math.round(avg);
}

console.log(average(scores));
console.log(average(scores2));