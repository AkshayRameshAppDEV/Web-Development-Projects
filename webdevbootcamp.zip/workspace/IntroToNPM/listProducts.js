var faker = require("faker");
var productName1 = faker.commerce.productName();
var productName2 = faker.commerce.productName();
var productName3 = faker.commerce.productName();
var productName4 = faker.commerce.productName();
var productName5 = faker.commerce.productName();
var productName6 = faker.commerce.productName();
var productName7 = faker.commerce.productName();
var productName8 = faker.commerce.productName();
var productName9 = faker.commerce.productName();
var productName10 = faker.commerce.productName();

var price1 = faker.commerce.price();
var price2 = faker.commerce.price();
var price3 = faker.commerce.price();
var price4 = faker.commerce.price();
var price5 = faker.commerce.price();
var price6 = faker.commerce.price();
var price7 = faker.commerce.price();
var price8 = faker.commerce.price();
var price9 = faker.commerce.price();
var price10 = faker.commerce.price();


console.log("THE PRODUCT NAMES and PRICES");
console.log(productName1+" "+price1);
console.log(productName2+" "+price2);
console.log(productName3+" "+price3);
console.log(productName4+" "+price4);
console.log(productName5+" "+price5);
console.log(productName6+" "+price6);
console.log(productName7+" "+price7);
console.log(productName8+" "+price8);
console.log(productName9+" "+price9);
console.log(productName10+" "+price10);



