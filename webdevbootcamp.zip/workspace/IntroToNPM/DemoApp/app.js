var jokes = require("knock-knock-jokes");
console.log(jokes());