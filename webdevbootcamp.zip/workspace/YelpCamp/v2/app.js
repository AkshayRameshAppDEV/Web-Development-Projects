var express      = require("express"),
    mongoose     = require("mongoose"),
    app          = express(),
    bodyParser   = require("body-parser");

mongoose.connect("mongodb://localhost/yelp_camp");
app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine", "ejs");

//Schema SETUP

var campgroundSchema = new mongoose.Schema({
   
   name: String,
   image: String,
   description: String()
    
});

var Campground = mongoose.model("Campground",campgroundSchema);

// Campground.create(
//     {
    
//         name:"Granite Hill", 
//         image:"https://farm4.staticflickr.com/3270/2617191414_c5d8a25a94.jpg",
//         description: "This is a huge granite hill,no bathrooms. No water. Beautiful granite!"
    
//     }, 
//     function(err,campground){
//     if(err)
//     {
//         console.log(err);
//     }
//     else
//     {
//         console.log("NEWLY CREATED CAMPGROUND: ");
//         console.log(campground);
//     }
// });


//  var campgrounds = [
//         {name:"Salmon Creek", image:"https://farm7.staticflickr.com/6089/6094103869_d53a990c83.jpg"},
//         {name:"Granite Hill", image:"https://farm4.staticflickr.com/3270/2617191414_c5d8a25a94.jpg"},
//         {name:"Mountain Goat's Rest", image:"https://farm8.staticflickr.com/7042/7121867321_65b5f46ef1.jpg"}
//         ];



app.get("/",function(req,res)
{
    res.render("landing");
});

app.post("/campgrounds",function(req,res)
{
    var name = req.body.name;
    var image = req.body.image;
    var desc = req.body.description;
    
    var newCampground = {name:name, image:image, description:desc};
    
    Campground.create(newCampground,function(err,newlyCreated){
        
        if(err)
        {
            console.log(err);
        }
        else
        {
             res.redirect("/campgrounds"); //default redirect as get request
        }
        
    });
    
   
});

app.get("/campgrounds",function(req,res)
{
    Campground.find({},function(err,allCampgrounds){
        if(err)
        {
            console.log(err);
        }
        else
        {
            res.render("index",{campgrounds:allCampgrounds});
        }
    });
    
    
    
});

app.get("/campgrounds/new",function(req, res) {
    res.render("new");
});


app.get("/campgrounds/:id",function(req, res) {
    Campground.findById( req.params.id,function(err, foundCampground)
    {
        if(err)
        {
            console.log(err);
        }
        else
        {
            res.render("show",{campground:foundCampground});
        }
        
        
    });
   
    
})

app.listen(process.env.PORT,process.env.IP,function()
{
   console.log("The YelpCamp server has Started!");
});